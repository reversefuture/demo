require("./style.css");
document.write(require("./content.js"));
document.write('<br/>Hello world!')