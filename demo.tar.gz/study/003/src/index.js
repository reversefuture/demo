require("!style-loader!css-loader!./style.css");
var helloComponent = require("./hello.js");

document.body.appendChild(helloComponent());