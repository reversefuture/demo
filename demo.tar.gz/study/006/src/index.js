require("./style.css");
require("./css/font-awesome.min.css");
var helloComponent = require("./hello.js");
var fonts = require("./fonts.js");
var Data = require("./data.xml");

document.body.appendChild(helloComponent());
document.body.appendChild(fonts());
console.log(JSON.stringify(Data));
