console.log('The print.js module has loaded! See the network tab in dev tools...');

export default () => {
  console.log('I get called from print.js!');
}