import printMe from './print.js';

console.log('Another module loaded.');