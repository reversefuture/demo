
export default function printMe2() {
  console.log('I get called from print2.js!');
}