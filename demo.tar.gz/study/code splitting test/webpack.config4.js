  const path = require('path');
 const webpack = require('webpack');
  const HTMLWebpackPlugin = require('html-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');

  module.exports = {
    entry: {
      index: './src/index1.js',
      another: './src/another-module.js',
      JQBootstrap: ['./src/jquery.js', './src/bootstrap.min.js'],
      vue: ['./src/vue.min.js']
      // chunk: ["./src/jquery", "./src/print"],//插件中name,filename必须以这个key为值
    },
    plugins: [
    new CleanWebpackPlugin(['dist']),
      new HTMLWebpackPlugin({
        title: 'Code Splitting'
      }),
      new webpack.optimize.CommonsChunkPlugin({
     name: ["common","JQBootstrap", "vue", "load"],
       // filename:";nachunk.js"//忽略则以name为输出文件的名字，否则以此为输出文件名字
      })
    ],
    output: {
      filename: '[name].bundle.js' , //不使用[name]，并且插件中没有filename，这输出文件中只用chunk.js的内容， 
      path: path.resolve(__dirname, 'dist')
    }
  };