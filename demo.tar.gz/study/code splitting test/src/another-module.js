import printMe from './print.js';
import printMe2 from './print2.js';
import './jquery.js'
console.log('Another module loaded.');