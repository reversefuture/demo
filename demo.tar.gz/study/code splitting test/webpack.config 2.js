  const path = require('path');
 const webpack = require('webpack');
  const HTMLWebpackPlugin = require('html-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');

  module.exports = {
    entry: {
      index: './src/index.js',
      another: './src/another-module.js',
      vendor: ["./src/jquery", "./src/bootstrap.min.js"],//插件中name,filename必须以这个key为值
    },
    plugins: [
    new CleanWebpackPlugin(['dist']),
      new HTMLWebpackPlugin({
        title: 'Code Splitting'
      }),
      new webpack.optimize.CommonsChunkPlugin({
  name: "app",
  // or
  // names: ["app", "subPageA"]
  // the name or list of names must match the name or names
  // of the entry points that create the async chunks

  children: true,
  // (use all children of the chunk)

  async: true,
  // (create an async commons chunk)

  minChunks: 2,
  // (2 children must share the module before it's separated)
        })
    ],
    output: {
      filename: '[name].bundle.js' , //不使用[name]，并且插件中没有filename，这输出文件中只用chunk.js的内容， 
      path: path.resolve(__dirname, 'dist')
    }
  };