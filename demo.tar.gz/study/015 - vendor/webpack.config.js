  const path = require('path');
 const webpack = require('webpack');
  const HTMLWebpackPlugin = require('html-webpack-plugin');
 const CleanWebpackPlugin = require('clean-webpack-plugin');

  module.exports = {
    entry: {
      index: './src/index.js',
      another: './src/another-module.js',
      vendor: ['./src/jquery.js', './src/vue.min.js']
    },
    plugins: [
      new CleanWebpackPlugin(['dist']),
      new HTMLWebpackPlugin({
        title: 'Code Splitting'
      }),
 //should be the same order as entry
      new webpack.optimize.CommonsChunkPlugin({
        name : "vendor",
        minChunks : Infinity
          // (with more entries, this ensures that no other module
  //  goes into the vendor chunk)
    }),
      new webpack.optimize.CommonsChunkPlugin({
         name: "common", // Specify the common bundle's name.
         filename: "commons.bundle.js",
         minChunks:2
      })

    ],
    output: {
      filename: '[name].bundle.js',
      path: path.resolve(__dirname, 'dist')
    }
  };