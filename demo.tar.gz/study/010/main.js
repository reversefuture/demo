import {cube} from './maths.js';
console.log(cube(5)); // 125