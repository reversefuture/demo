var helloComponent = require("./hello.js");

document.body.appendChild(helloComponent());