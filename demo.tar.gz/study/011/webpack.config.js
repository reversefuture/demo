 const path = require('path');
const CleanWebpackPlugin = require('clean-webpack-plugin');
  module.exports = {
    entry: './main.js',
    output: {
      filename: 'bundle.js',
      path: path.resolve(__dirname, 'dist')
    },
    plugins: [
      new CleanWebpackPlugin(['dist'])
    ],
   module: {
        rules: [
        {
      test: /\.js$/,
      exclude: /(node_modules|bower_components)/,
      use: {
        loader: 'babel-loader',
        options: {
/*          presets: [
            ['es2015', { modules: false }]
          ]*/
          /*presets: ['es2015']*/
        }
      }
    }]
   }
 }