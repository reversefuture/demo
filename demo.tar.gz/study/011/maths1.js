exports.square = function (x) {
    return x * x;
}

exports.cube =  function (x) {
    return x * x * x;
}