import './style.css';
import './css/font-awesome.min.css';
import hello from './hello.js';
import fonts from './fonts.js';
import Data from './data.xml';

document.body.appendChild(hello());
document.body.appendChild(fonts());
console.log(JSON.stringify(Data));
