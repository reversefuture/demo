import printMe2 from './print2.js'

function component() {
    var element = document.createElement('div');
  var button = document.createElement('button');
  var br = document.createElement('br');

  button.innerHTML = 'Click me and look at the console!';
    element.innerHTML = 'Hello webpack.';
  element.appendChild(br);
  element.appendChild(button);

  button.onclick = function (e) {
     import('./print')  /* webpackChunkName: "print" */ 
     .then(function(module){
        var print = module.default;
        print();
    });
    }
    return element;
  }
  
printMe2();
document.body.appendChild(component());