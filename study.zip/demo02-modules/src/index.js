import printMe from './print.js';

  function component() {
    var element = document.createElement('div');

    element.innerHTML = "Hello Webpack!";
    element.classList.add('hello');

    return element;
  }

  printMe();
document.body.appendChild(component());