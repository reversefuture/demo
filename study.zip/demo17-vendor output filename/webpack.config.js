  const path = require('path');
 const webpack = require('webpack');
  const HTMLWebpackPlugin = require('html-webpack-plugin');
 const CleanWebpackPlugin = require('clean-webpack-plugin');

  module.exports = {
    entry: {
      index: './src/index.js',
      vendor: ['./src/vue.min.js']
    },
    plugins: [
      new CleanWebpackPlugin(['dist']),
      new HTMLWebpackPlugin({
        title: 'Caching'
      }),
 //should be prior to runtime config
      new webpack.optimize.CommonsChunkPlugin({
        name : "vendor",
        filename:"vendor.js"
    }),
      new webpack.optimize.CommonsChunkPlugin({
         name: "runtime"
      })
    ],
    output: {
      filename: '[name].[chunkhash].js',
      path: path.resolve(__dirname, 'dist')
    }
  };