import printMe from './print.js';
import 'style-loader!css-loader!./style.css';

  function component() {
    var element = document.createElement('div');

    element.innerHTML = "Hello Webpack!";
    element.classList.add('hello');

    return element;
  }

  printMe();
document.body.appendChild(component());