import './style.css';
  export default function hello() {
    var element = document.createElement('div');
    var Icon = require('./icon.png')
    element.innerHTML = "Hello Webpack!";
    element.classList.add('hello');
    var myIcon = new Image();
    myIcon.src = Icon;

    element.appendChild(myIcon);
    return element;
  }
