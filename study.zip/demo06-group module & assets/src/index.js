
import hello from './hello/hello.js';
import fonts from './fonts/fonts.js';

document.body.appendChild(hello());
document.body.appendChild(fonts());

