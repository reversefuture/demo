const path = require('path');
  const HtmlWebpackPlugin = require('html-webpack-plugin');
 const webpack = require('webpack');

  module.exports = {
    entry: {
      app: './src/index2.js'
    },
    devtool: 'inline-source-map',
    devServer: {
      contentBase: './dist',
     hot: true
    },
    module: {  
    rules: [
      {
        test: /\.css$/,
        use: [{
            loader: "style-loader" // creates style nodes from JS strings
        }, {
            loader: "css-loader" // translates CSS into CommonJS
        }]
      },
     ]
  	},
    plugins: [
      new HtmlWebpackPlugin({
        title: 'Hot Module Replacement'
      }),
     new webpack.HotModuleReplacementPlugin()
    ],
    output: {
      filename: '[name].bundle.js',
      path: path.resolve(__dirname, 'dist')
    }
  };