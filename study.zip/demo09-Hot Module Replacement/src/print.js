  export default function printMe() {
   console.log('Original log from Print.js!')
  }